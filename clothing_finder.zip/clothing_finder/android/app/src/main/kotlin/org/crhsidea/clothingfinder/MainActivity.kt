package org.crhsidea.clothingfinder

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
